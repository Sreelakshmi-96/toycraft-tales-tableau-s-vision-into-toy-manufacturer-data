export interface ToyManufacturerData {
  index: number;
  state: string;
  year: number;
  numberOfManufacturers: number;
}

export interface StateData {
  state: string;
  totalManufacturers: number;
  averageManufacturers: number;
  yearlyData: { year: number; count: number }[];
}

export interface YearlyTrend {
  year: number;
  totalManufacturers: number;
}