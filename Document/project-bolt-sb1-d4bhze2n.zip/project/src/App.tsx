import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import YearlyTrendChart from './components/YearlyTrendChart';
import TopStatesChart from './components/TopStatesChart';
import YearSelector from './components/YearSelector';
import YearlyStateChart from './components/YearlyStateChart';
import KeyInsights from './components/KeyInsights';
import { parseCSVData, getStateAnalysis, getYearlyTrends, getYearlyStateData } from './utils/dataProcessor';
import { ToyManufacturerData, StateData, YearlyTrend } from './types';

function App() {
  const [data, setData] = useState<ToyManufacturerData[]>([]);
  const [stateAnalysis, setStateAnalysis] = useState<StateData[]>([]);
  const [yearlyTrends, setYearlyTrends] = useState<YearlyTrend[]>([]);
  const [selectedYear, setSelectedYear] = useState<number>(2016);
  const [yearlyStateData, setYearlyStateData] = useState<ToyManufacturerData[]>([]);
  const [loading, setLoading] = useState(true);

  const availableYears = [2005, 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2014, 2015, 2016];

  useEffect(() => {
    const loadData = async () => {
      try {
        const response = await fetch('/ToyCraft_Tales.csv');
        const csvText = await response.text();
        
        const parsedData = parseCSVData(csvText);
        const stateData = getStateAnalysis(parsedData);
        const trends = getYearlyTrends(csvText);
        
        setData(parsedData);
        setStateAnalysis(stateData);
        setYearlyTrends(trends);
        setLoading(false);
      } catch (error) {
        console.error('Error loading data:', error);
        setLoading(false);
      }
    };

    loadData();
  }, []);

  useEffect(() => {
    if (data.length > 0) {
      const yearData = getYearlyStateData(data, selectedYear);
      setYearlyStateData(yearData);
    }
  }, [data, selectedYear]);

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading ToyCraft Tales data...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <Header />
      
      <main className="container mx-auto px-6 py-8 space-y-8">
        {/* Key Insights */}
        <KeyInsights stateData={stateAnalysis} yearlyTrends={yearlyTrends} />
        
        {/* National Trends */}
        <YearlyTrendChart data={yearlyTrends} />
        
        {/* Top States Overall */}
        <TopStatesChart data={stateAnalysis} />
        
        {/* Year Selection */}
        <YearSelector 
          selectedYear={selectedYear}
          onYearChange={setSelectedYear}
          availableYears={availableYears}
        />
        
        {/* Yearly State Analysis */}
        <YearlyStateChart data={yearlyStateData} year={selectedYear} />
        
        {/* Footer */}
        <footer className="bg-white rounded-xl shadow-lg p-6 border border-gray-100 text-center">
          <p className="text-gray-600">
            <strong>ToyCraft Tales</strong> - A comprehensive analysis of US toy manufacturer data (2005-2016)
          </p>
          <p className="text-sm text-gray-500 mt-2">
            SmartInternz Project | Data Visualization & Business Intelligence
          </p>
        </footer>
      </main>
    </div>
  );
}

export default App;