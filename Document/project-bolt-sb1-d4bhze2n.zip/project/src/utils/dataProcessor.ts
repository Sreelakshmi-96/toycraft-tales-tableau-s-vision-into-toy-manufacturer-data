import { ToyManufacturerData, StateData, YearlyTrend } from '../types';

export const parseCSVData = (csvText: string): ToyManufacturerData[] => {
  const lines = csvText.trim().split('\n');
  const data: ToyManufacturerData[] = [];
  
  // Skip header row
  for (let i = 1; i < lines.length; i++) {
    const [index, state, year, numberOfManufacturers] = lines[i].split(',');
    
    // Skip United States totals and Puerto Rico for state analysis
    if (state !== 'United States' && state !== 'Puerto Rico') {
      data.push({
        index: parseInt(index),
        state: state.trim(),
        year: parseInt(year),
        numberOfManufacturers: parseInt(numberOfManufacturers)
      });
    }
  }
  
  return data;
};

export const getYearlyTrends = (csvText: string): YearlyTrend[] => {
  const lines = csvText.trim().split('\n');
  const trends: YearlyTrend[] = [];
  
  for (let i = 1; i < lines.length; i++) {
    const [, state, year, numberOfManufacturers] = lines[i].split(',');
    
    if (state === 'United States') {
      trends.push({
        year: parseInt(year),
        totalManufacturers: parseInt(numberOfManufacturers)
      });
    }
  }
  
  return trends.sort((a, b) => a.year - b.year);
};

export const getStateAnalysis = (data: ToyManufacturerData[]): StateData[] => {
  const stateMap = new Map<string, ToyManufacturerData[]>();
  
  data.forEach(item => {
    if (!stateMap.has(item.state)) {
      stateMap.set(item.state, []);
    }
    stateMap.get(item.state)!.push(item);
  });
  
  const stateAnalysis: StateData[] = [];
  
  stateMap.forEach((items, state) => {
    const totalManufacturers = items.reduce((sum, item) => sum + item.numberOfManufacturers, 0);
    const averageManufacturers = totalManufacturers / items.length;
    const yearlyData = items
      .map(item => ({ year: item.year, count: item.numberOfManufacturers }))
      .sort((a, b) => a.year - b.year);
    
    stateAnalysis.push({
      state,
      totalManufacturers,
      averageManufacturers,
      yearlyData
    });
  });
  
  return stateAnalysis.sort((a, b) => b.totalManufacturers - a.totalManufacturers);
};

export const getTopStates = (stateAnalysis: StateData[], count: number = 10): StateData[] => {
  return stateAnalysis.slice(0, count);
};

export const getYearlyStateData = (data: ToyManufacturerData[], year: number) => {
  return data
    .filter(item => item.year === year)
    .sort((a, b) => b.numberOfManufacturers - a.numberOfManufacturers)
    .slice(0, 15);
};