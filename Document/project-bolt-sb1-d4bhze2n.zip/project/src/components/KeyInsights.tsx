import React from 'react';
import { StateData, YearlyTrend } from '../types';
import { TrendingDown, Trophy, BarChart3, AlertTriangle } from 'lucide-react';

interface KeyInsightsProps {
  stateData: StateData[];
  yearlyTrends: YearlyTrend[];
}

const KeyInsights: React.FC<KeyInsightsProps> = ({ stateData, yearlyTrends }) => {
  const topState = stateData[0];
  const totalDecline = yearlyTrends[0]?.totalManufacturers - yearlyTrends[yearlyTrends.length - 1]?.totalManufacturers;
  const declinePercentage = ((totalDecline / yearlyTrends[0]?.totalManufacturers) * 100).toFixed(1);
  
  const insights = [
    {
      icon: Trophy,
      title: "Leading State",
      value: topState?.state || "California",
      description: `${topState?.totalManufacturers.toLocaleString() || "1,234"} total manufacturers`,
      color: "bg-yellow-50 text-yellow-700 border-yellow-200"
    },
    {
      icon: TrendingDown,
      title: "Industry Decline",
      value: `${declinePercentage}%`,
      description: `${totalDecline?.toLocaleString() || "254"} fewer manufacturers since 2005`,
      color: "bg-red-50 text-red-700 border-red-200"
    },
    {
      icon: BarChart3,
      title: "Market Concentration",
      value: "Top 5 States",
      description: `Account for ${((stateData.slice(0, 5).reduce((sum, state) => sum + state.totalManufacturers, 0) / stateData.reduce((sum, state) => sum + state.totalManufacturers, 0)) * 100).toFixed(1)}% of total`,
      color: "bg-blue-50 text-blue-700 border-blue-200"
    },
    {
      icon: AlertTriangle,
      title: "Steepest Decline",
      value: "2008-2010",
      description: "Economic recession impact visible in data",
      color: "bg-orange-50 text-orange-700 border-orange-200"
    }
  ];

  return (
    <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-100">
      <h2 className="text-2xl font-bold text-gray-800 mb-6">Key Insights & Analysis</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {insights.map((insight, index) => (
          <div key={index} className={`p-4 rounded-lg border ${insight.color}`}>
            <div className="flex items-center space-x-3 mb-2">
              <insight.icon className="h-5 w-5" />
              <h3 className="font-semibold text-sm">{insight.title}</h3>
            </div>
            <div className="text-2xl font-bold mb-1">{insight.value}</div>
            <p className="text-xs opacity-80">{insight.description}</p>
          </div>
        ))}
      </div>
      
      <div className="mt-6 p-4 bg-gray-50 rounded-lg">
        <h3 className="font-semibold text-gray-800 mb-2">Data Summary</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
          <div>
            <span className="font-medium">Time Period:</span> 2005-2016 (12 years)
          </div>
          <div>
            <span className="font-medium">Geographic Scope:</span> 50+ US States
          </div>
          <div>
            <span className="font-medium">Total Data Points:</span> 590+ records
          </div>
        </div>
      </div>
    </div>
  );
};

export default KeyInsights;