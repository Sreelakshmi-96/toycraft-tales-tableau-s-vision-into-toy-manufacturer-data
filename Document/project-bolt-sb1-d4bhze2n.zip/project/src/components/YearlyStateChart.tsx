import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { ToyManufacturerData } from '../types';
import { MapPin } from 'lucide-react';

interface YearlyStateChartProps {
  data: ToyManufacturerData[];
  year: number;
}

const YearlyStateChart: React.FC<YearlyStateChartProps> = ({ data, year }) => {
  const formatTooltip = (value: number, name: string) => {
    return [value.toLocaleString(), `Manufacturers in ${year}`];
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-100">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold text-gray-800 mb-2">State Rankings for {year}</h2>
          <p className="text-gray-600">Top 15 states by number of toy manufacturers</p>
        </div>
        <div className="bg-green-50 p-3 rounded-lg">
          <MapPin className="h-6 w-6 text-green-600" />
        </div>
      </div>
      
      <div className="h-96">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 60 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
            <XAxis 
              dataKey="state" 
              stroke="#6b7280"
              fontSize={11}
              angle={-45}
              textAnchor="end"
              height={80}
              tickLine={false}
            />
            <YAxis 
              stroke="#6b7280"
              fontSize={12}
              tickLine={false}
            />
            <Tooltip 
              formatter={formatTooltip}
              labelStyle={{ color: '#374151' }}
              contentStyle={{ 
                backgroundColor: 'white', 
                border: '1px solid #e5e7eb',
                borderRadius: '8px',
                boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
              }}
            />
            <Bar 
              dataKey="numberOfManufacturers" 
              fill="#10b981"
              radius={[4, 4, 0, 0]}
            />
          </BarChart>
        </ResponsiveContainer>
      </div>
      
      <div className="mt-4 p-4 bg-green-50 rounded-lg border border-green-200">
        <p className="text-green-800 text-sm">
          <strong>Year {year} Leader:</strong> {data[0]?.state} with {data[0]?.numberOfManufacturers} manufacturers
        </p>
      </div>
    </div>
  );
};

export default YearlyStateChart;