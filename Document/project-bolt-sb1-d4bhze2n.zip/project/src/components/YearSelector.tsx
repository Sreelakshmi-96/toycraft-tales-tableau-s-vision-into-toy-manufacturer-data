import React from 'react';
import { Calendar } from 'lucide-react';

interface YearSelectorProps {
  selectedYear: number;
  onYearChange: (year: number) => void;
  availableYears: number[];
}

const YearSelector: React.FC<YearSelectorProps> = ({ selectedYear, onYearChange, availableYears }) => {
  return (
    <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-100">
      <div className="flex items-center space-x-3 mb-4">
        <div className="bg-blue-50 p-2 rounded-lg">
          <Calendar className="h-5 w-5 text-blue-600" />
        </div>
        <h3 className="text-lg font-semibold text-gray-800">Select Year for Analysis</h3>
      </div>
      
      <div className="grid grid-cols-3 md:grid-cols-6 gap-2">
        {availableYears.map(year => (
          <button
            key={year}
            onClick={() => onYearChange(year)}
            className={`px-4 py-2 rounded-lg font-medium transition-all duration-200 ${
              selectedYear === year
                ? 'bg-blue-600 text-white shadow-md transform scale-105'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200 hover:scale-102'
            }`}
          >
            {year}
          </button>
        ))}
      </div>
    </div>
  );
};

export default YearSelector;