import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { StateData } from '../types';
import { Award } from 'lucide-react';

interface TopStatesChartProps {
  data: StateData[];
}

const TopStatesChart: React.FC<TopStatesChartProps> = ({ data }) => {
  const topStates = data.slice(0, 10);

  const formatTooltip = (value: number, name: string) => {
    return [value.toLocaleString(), 'Total Manufacturers (2005-2016)'];
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-100">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold text-gray-800 mb-2">Top 10 Manufacturing States</h2>
          <p className="text-gray-600">Cumulative toy manufacturers by state (2005-2016)</p>
        </div>
        <div className="bg-yellow-50 p-3 rounded-lg">
          <Award className="h-6 w-6 text-yellow-600" />
        </div>
      </div>
      
      <div className="h-96">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={topStates} margin={{ top: 20, right: 30, left: 20, bottom: 60 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
            <XAxis 
              dataKey="state" 
              stroke="#6b7280"
              fontSize={11}
              angle={-45}
              textAnchor="end"
              height={80}
              tickLine={false}
            />
            <YAxis 
              stroke="#6b7280"
              fontSize={12}
              tickLine={false}
              tickFormatter={(value) => value.toLocaleString()}
            />
            <Tooltip 
              formatter={formatTooltip}
              labelStyle={{ color: '#374151' }}
              contentStyle={{ 
                backgroundColor: 'white', 
                border: '1px solid #e5e7eb',
                borderRadius: '8px',
                boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
              }}
            />
            <Bar 
              dataKey="totalManufacturers" 
              fill="#8b5cf6"
              radius={[4, 4, 0, 0]}
            />
          </BarChart>
        </ResponsiveContainer>
      </div>
      
      <div className="mt-4 grid grid-cols-2 md:grid-cols-5 gap-4">
        {topStates.slice(0, 5).map((state, index) => (
          <div key={state.state} className="text-center p-3 bg-purple-50 rounded-lg">
            <div className="text-2xl font-bold text-purple-600">#{index + 1}</div>
            <div className="text-sm font-medium text-gray-700">{state.state}</div>
            <div className="text-xs text-gray-500">{state.totalManufacturers.toLocaleString()}</div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default TopStatesChart;