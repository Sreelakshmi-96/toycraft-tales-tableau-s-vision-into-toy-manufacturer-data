import React from 'react';
import { Blocks, BarChart3 } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-700 text-white shadow-lg">
      <div className="container mx-auto px-6 py-8">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="bg-white/20 p-3 rounded-xl backdrop-blur-sm">
              <Blocks className="h-8 w-8" />
            </div>
            <div>
              <h1 className="text-3xl font-bold tracking-tight">ToyCraft Tales</h1>
              <p className="text-blue-100 text-lg">Tableau's Vision into Toy Manufacturer Data</p>
            </div>
          </div>
          <div className="flex items-center space-x-2 bg-white/10 px-4 py-2 rounded-lg backdrop-blur-sm">
            <BarChart3 className="h-5 w-5" />
            <span className="font-medium">SmartInternz Project</span>
          </div>
        </div>
        <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white/10 p-4 rounded-lg backdrop-blur-sm">
            <h3 className="font-semibold text-blue-100">Data Period</h3>
            <p className="text-2xl font-bold">2005 - 2016</p>
          </div>
          <div className="bg-white/10 p-4 rounded-lg backdrop-blur-sm">
            <h3 className="font-semibold text-blue-100">Geographic Coverage</h3>
            <p className="text-2xl font-bold">50+ US States</p>
          </div>
          <div className="bg-white/10 p-4 rounded-lg backdrop-blur-sm">
            <h3 className="font-semibold text-blue-100">Analysis Focus</h3>
            <p className="text-2xl font-bold">Manufacturing Trends</p>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;