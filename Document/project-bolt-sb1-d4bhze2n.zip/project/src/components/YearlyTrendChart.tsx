import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { YearlyTrend } from '../types';
import { TrendingDown } from 'lucide-react';

interface YearlyTrendChartProps {
  data: YearlyTrend[];
}

const YearlyTrendChart: React.FC<YearlyTrendChartProps> = ({ data }) => {
  const formatTooltip = (value: number, name: string) => {
    return [value.toLocaleString(), 'Total Manufacturers'];
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-100">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold text-gray-800 mb-2">National Manufacturing Trends</h2>
          <p className="text-gray-600">Total toy manufacturers across the United States (2005-2016)</p>
        </div>
        <div className="bg-red-50 p-3 rounded-lg">
          <TrendingDown className="h-6 w-6 text-red-600" />
        </div>
      </div>
      
      <div className="h-80">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
            <XAxis 
              dataKey="year" 
              stroke="#6b7280"
              fontSize={12}
              tickLine={false}
            />
            <YAxis 
              stroke="#6b7280"
              fontSize={12}
              tickLine={false}
              tickFormatter={(value) => value.toLocaleString()}
            />
            <Tooltip 
              formatter={formatTooltip}
              labelStyle={{ color: '#374151' }}
              contentStyle={{ 
                backgroundColor: 'white', 
                border: '1px solid #e5e7eb',
                borderRadius: '8px',
                boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
              }}
            />
            <Line 
              type="monotone" 
              dataKey="totalManufacturers" 
              stroke="#3b82f6" 
              strokeWidth={3}
              dot={{ fill: '#3b82f6', strokeWidth: 2, r: 5 }}
              activeDot={{ r: 7, stroke: '#3b82f6', strokeWidth: 2 }}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
      
      <div className="mt-4 p-4 bg-amber-50 rounded-lg border border-amber-200">
        <p className="text-amber-800 text-sm">
          <strong>Key Insight:</strong> The data shows a consistent decline in toy manufacturers from 811 in 2005 to 557 in 2016, 
          representing a 31% decrease over the 12-year period.
        </p>
      </div>
    </div>
  );
};

export default YearlyTrendChart;